import { Outlet } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { format } from 'date-fns';
import Sidebar from './Sidebar';
import Topbar from './Topbar';
import { ToastProvider } from '../ui/Toast';
import { useFinanceStore } from '../../store/useFinanceStore';

export default function AppLayout() {
  const [competencia, setCompetencia] = useState(format(new Date(), 'yyyy-MM'));
  const marcarVencidos = useFinanceStore((s) => s.marcarVencidos);

  useEffect(() => {
    marcarVencidos();
  }, [marcarVencidos]);

  return (
    <ToastProvider>
      <div className="flex h-screen overflow-hidden bg-slate-50">
        <Sidebar />
        <div className="flex flex-col flex-1 overflow-hidden">
          <Topbar competencia={competencia} onCompetenciaChange={setCompetencia} />
          <main className="flex-1 overflow-y-auto p-6">
            <Outlet context={{ competencia }} />
          </main>
        </div>
      </div>
    </ToastProvider>
  );
}
