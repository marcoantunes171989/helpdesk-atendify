import { clsx } from 'clsx';

interface BadgeProps {
  variant?: 'green' | 'red' | 'amber' | 'blue' | 'gray' | 'purple';
  dot?: boolean;
  children: React.ReactNode;
  className?: string;
}

const variants = {
  green: 'badge-green',
  red: 'badge-red',
  amber: 'badge-amber',
  blue: 'badge-blue',
  gray: 'badge-gray',
  purple: 'badge-purple',
};

const dotColors = {
  green: 'bg-emerald-500',
  red: 'bg-red-500',
  amber: 'bg-amber-500',
  blue: 'bg-blue-500',
  gray: 'bg-slate-400',
  purple: 'bg-purple-500',
};

export default function Badge({ variant = 'gray', dot, children, className }: BadgeProps) {
  return (
    <span className={clsx(variants[variant], className)}>
      {dot && <span className={clsx('w-1.5 h-1.5 rounded-full', dotColors[variant])} />}
      {children}
    </span>
  );
}
