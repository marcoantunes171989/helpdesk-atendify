import { format, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export const fmtMoeda = (v: number) =>
  v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

export const fmtData = (d: string) =>
  format(parseISO(d), 'dd/MM/yyyy', { locale: ptBR });

export const fmtDataHora = (d: string) =>
  format(parseISO(d), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR });

export const fmtMesAno = (competencia: string) => {
  const [ano, mes] = competencia.split('-');
  return format(new Date(Number(ano), Number(mes) - 1, 1), 'MMMM yyyy', { locale: ptBR });
};

export const fmtPercentual = (v: number) => `${v.toFixed(1)}%`;

export const competenciaAtual = () =>
  format(new Date(), 'yyyy-MM');
