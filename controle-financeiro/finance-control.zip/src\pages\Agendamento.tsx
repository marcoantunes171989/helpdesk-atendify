import { useState } from 'react';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, isToday, parseISO, addMonths, subMonths } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { ChevronLeft, ChevronRight, Repeat } from 'lucide-react';
import { clsx } from 'clsx';
import { useFinanceStore } from '../store/useFinanceStore';
import { useEmpresaStore } from '../store/useEmpresaStore';
import { useCategoriaStore } from '../store/useCategoriaStore';
import { fmtMoeda, fmtData } from '../utils/format';
import StatusBadge from '../components/shared/StatusBadge';

export default function Agendamento() {
  const [mesAtual, setMesAtual] = useState(new Date());
  const [diaSelecionado, setDiaSelecionado] = useState<Date | null>(null);

  const { lancamentos } = useFinanceStore();
  const empresas = useEmpresaStore((s) => s.empresas);
  const categorias = useCategoriaStore((s) => s.categorias);

  const enriched = lancamentos.map((l) => ({
    ...l,
    empresa: empresas.find((e) => e.id === l.empresaId),
    categoria: categorias.find((c) => c.id === l.categoriaId),
  }));

  const inicio = startOfMonth(mesAtual);
  const fim = endOfMonth(mesAtual);
  const dias = eachDayOfInterval({ start: inicio, end: fim });

  const getLancamentosDodia = (dia: Date) =>
    enriched.filter((l) => isSameDay(parseISO(l.dataVencimento), dia));

  const lancamentosDoMes = enriched.filter((l) => {
    const comp = format(mesAtual, 'yyyy-MM');
    return l.competencia === comp;
  });

  const receber = lancamentosDoMes.filter((l) => l.tipo === 'credito').reduce((a, l) => a + l.valor, 0);
  const pagar = lancamentosDoMes.filter((l) => l.tipo === 'debito').reduce((a, l) => a + l.valor, 0);
  const saldo = receber - pagar;

  const contasFixas = enriched.filter((l) => l.tipoRecorrencia === 'fixo');
  const proximasContas = enriched
    .filter((l) => l.status === 'pendente' || l.status === 'vencido')
    .sort((a, b) => new Date(a.dataVencimento).getTime() - new Date(b.dataVencimento).getTime())
    .slice(0, 10);

  const diasSemana = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
  const offset = inicio.getDay();

  const lancamentosDiaSelecionado = diaSelecionado ? getLancamentosDodia(diaSelecionado) : [];

  return (
    <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
      {/* Calendário */}
      <div className="xl:col-span-2">
        <div className="card p-4">
          {/* Cabeçalho */}
          <div className="flex items-center justify-between mb-4">
            <button onClick={() => setMesAtual(subMonths(mesAtual, 1))} className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-600">
              <ChevronLeft size={16} />
            </button>
            <h2 className="text-sm font-semibold text-slate-900 capitalize">
              {format(mesAtual, 'MMMM yyyy', { locale: ptBR })}
            </h2>
            <button onClick={() => setMesAtual(addMonths(mesAtual, 1))} className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-600">
              <ChevronRight size={16} />
            </button>
          </div>

          {/* Dias da semana */}
          <div className="grid grid-cols-7 mb-2">
            {diasSemana.map((d) => (
              <div key={d} className="text-center text-xs font-medium text-slate-400 py-1">{d}</div>
            ))}
          </div>

          {/* Células */}
          <div className="grid grid-cols-7 gap-1">
            {Array.from({ length: offset }).map((_, i) => (
              <div key={`empty-${i}`} />
            ))}
            {dias.map((dia) => {
              const lancsDia = getLancamentosDodia(dia);
              const temCredito = lancsDia.some((l) => l.tipo === 'credito');
              const temDebito = lancsDia.some((l) => l.tipo === 'debito');
              const selecionado = diaSelecionado && isSameDay(dia, diaSelecionado);

              return (
                <button
                  key={dia.toISOString()}
                  onClick={() => setDiaSelecionado(selecionado ? null : dia)}
                  className={clsx(
                    'relative p-1.5 rounded-lg text-xs transition-colors min-h-[48px] text-left',
                    isToday(dia) && 'border-2 border-brand-400',
                    selecionado ? 'bg-brand-50' : 'hover:bg-slate-50',
                  )}
                >
                  <span className={clsx('font-medium', isToday(dia) ? 'text-brand-600' : 'text-slate-700')}>
                    {format(dia, 'd')}
                  </span>
                  <div className="flex gap-0.5 mt-1 flex-wrap">
                    {temCredito && <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />}
                    {temDebito && <span className="w-1.5 h-1.5 rounded-full bg-red-400" />}
                    {lancsDia.length > 2 && (
                      <span className="text-[9px] text-slate-400">+{lancsDia.length - 2}</span>
                    )}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Popup do dia selecionado */}
          {diaSelecionado && lancamentosDiaSelecionado.length > 0 && (
            <div className="mt-4 border-t border-slate-100 pt-4">
              <h3 className="text-xs font-semibold text-slate-600 mb-2">
                {format(diaSelecionado, "dd 'de' MMMM", { locale: ptBR })}
              </h3>
              <div className="space-y-2">
                {lancamentosDiaSelecionado.map((l) => (
                  <div key={l.id} className="flex items-center justify-between p-2 rounded-lg bg-slate-50">
                    <div>
                      <p className="text-xs font-medium text-slate-800">{l.descricao}</p>
                      <p className="text-xs text-slate-400">{l.empresa?.nomeFantasia}</p>
                    </div>
                    <div className="text-right">
                      <p className={`text-xs font-semibold ${l.tipo === 'credito' ? 'text-emerald-600' : 'text-red-600'}`}>
                        {fmtMoeda(l.valor)}
                      </p>
                      <StatusBadge status={l.status} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Painel lateral */}
      <div className="space-y-4">
        {/* Resumo do mês */}
        <div className="card p-4">
          <h3 className="text-xs font-semibold text-slate-600 uppercase tracking-wide mb-3">Resumo do Mês</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-slate-600">A receber</span>
              <span className="font-semibold text-emerald-600">{fmtMoeda(receber)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-600">A pagar</span>
              <span className="font-semibold text-red-600">{fmtMoeda(pagar)}</span>
            </div>
            <div className="flex justify-between border-t border-slate-100 pt-2">
              <span className="text-slate-700 font-medium">Saldo</span>
              <span className={`font-bold ${saldo >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>{fmtMoeda(saldo)}</span>
            </div>
          </div>
        </div>

        {/* Contas fixas */}
        {contasFixas.length > 0 && (
          <div className="card p-4">
            <h3 className="text-xs font-semibold text-slate-600 uppercase tracking-wide mb-3">Contas Fixas</h3>
            <div className="space-y-2">
              {contasFixas.slice(0, 5).map((l) => (
                <div key={l.id} className="flex items-center gap-2 text-xs">
                  <Repeat size={12} className="text-slate-400 shrink-0" />
                  <span className="flex-1 text-slate-700 truncate">{l.descricao}</span>
                  <span className={`font-medium ${l.tipo === 'credito' ? 'text-emerald-600' : 'text-red-600'}`}>
                    {fmtMoeda(l.valor)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Próximas contas */}
        <div className="card p-4">
          <h3 className="text-xs font-semibold text-slate-600 uppercase tracking-wide mb-3">Próximos Vencimentos</h3>
          <div className="space-y-2">
            {proximasContas.map((l) => (
              <div key={l.id} className="flex items-start gap-2">
                <div className={`w-1.5 h-1.5 rounded-full mt-1.5 shrink-0 ${l.tipo === 'credito' ? 'bg-emerald-400' : 'bg-red-400'}`} />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-slate-800 truncate">{l.descricao}</p>
                  <p className="text-xs text-slate-400">{fmtData(l.dataVencimento)}</p>
                </div>
                <span className={`text-xs font-semibold shrink-0 ${l.tipo === 'credito' ? 'text-emerald-600' : 'text-red-600'}`}>
                  {fmtMoeda(l.valor)}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
