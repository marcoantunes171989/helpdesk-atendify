import { useLocation, useNavigate } from 'react-router-dom';
import { Plus, User, ChevronLeft, ChevronRight } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import Button from '../ui/Button';

const routeTitles: Record<string, string> = {
  '/dashboard': 'Dashboard',
  '/lancamentos': 'Lançamentos',
  '/pagar': 'Contas a Pagar',
  '/receber': 'Contas a Receber',
  '/agendamento': 'Agendamento',
  '/empresas': 'Empresas',
  '/categorias': 'Categorias',
  '/relatorios': 'Relatórios',
};

interface TopbarProps {
  competencia: string;
  onCompetenciaChange: (c: string) => void;
}

export default function Topbar({ competencia, onCompetenciaChange }: TopbarProps) {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const title = routeTitles[pathname] ?? 'FinanceControl';

  const [ano, mes] = competencia.split('-').map(Number);
  const dataCompetencia = new Date(ano, mes - 1, 1);

  const prev = () => {
    const d = new Date(ano, mes - 2, 1);
    onCompetenciaChange(format(d, 'yyyy-MM'));
  };

  const next = () => {
    const d = new Date(ano, mes, 1);
    onCompetenciaChange(format(d, 'yyyy-MM'));
  };

  return (
    <header className="h-14 border-b border-slate-200 bg-white flex items-center justify-between px-6 shrink-0">
      <h1 className="text-base font-semibold text-slate-900">{title}</h1>

      <div className="flex items-center gap-3">
        {/* Competência selector */}
        <div className="flex items-center gap-1 bg-slate-100 rounded-lg px-2 py-1">
          <button onClick={prev} className="p-0.5 text-slate-500 hover:text-slate-800">
            <ChevronLeft size={14} />
          </button>
          <span className="text-xs font-medium text-slate-700 w-24 text-center capitalize">
            {format(dataCompetencia, 'MMM yyyy', { locale: ptBR })}
          </span>
          <button onClick={next} className="p-0.5 text-slate-500 hover:text-slate-800">
            <ChevronRight size={14} />
          </button>
        </div>

        <Button
          variant="primary"
          size="sm"
          icon={<Plus size={14} />}
          onClick={() => navigate('/lancamentos')}
        >
          Novo lançamento
        </Button>

        <button className="w-8 h-8 rounded-full bg-brand-100 flex items-center justify-center text-brand-600">
          <User size={14} />
        </button>
      </div>
    </header>
  );
}
