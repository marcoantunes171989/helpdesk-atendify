import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  FileText,
  ArrowDownCircle,
  ArrowUpCircle,
  CalendarDays,
  Building2,
  Tag,
  BarChart3,
  TrendingDown,
} from 'lucide-react';
import { clsx } from 'clsx';
import { useFinanceStore } from '../../store/useFinanceStore';
import { useEmpresaStore } from '../../store/useEmpresaStore';

interface NavItem {
  to: string;
  label: string;
  icon: React.ReactNode;
  badgeCount?: number;
}

interface NavGroup {
  label: string;
  items: NavItem[];
}

export default function Sidebar() {
  const lancamentos = useFinanceStore((s) => s.lancamentos);
  const empresas = useEmpresaStore((s) => s.empresas);

  const vencidosPagar = lancamentos.filter((l) => l.tipo === 'debito' && l.status === 'vencido').length;
  const vencidosReceber = lancamentos.filter((l) => l.tipo === 'credito' && l.status === 'vencido').length;

  const groups: NavGroup[] = [
    {
      label: 'PRINCIPAL',
      items: [
        { to: '/dashboard', label: 'Dashboard', icon: <LayoutDashboard size={16} /> },
        { to: '/lancamentos', label: 'Lançamentos', icon: <FileText size={16} /> },
      ],
    },
    {
      label: 'FINANCEIRO',
      items: [
        { to: '/pagar', label: 'Contas a Pagar', icon: <ArrowDownCircle size={16} />, badgeCount: vencidosPagar },
        { to: '/receber', label: 'Contas a Receber', icon: <ArrowUpCircle size={16} />, badgeCount: vencidosReceber },
        { to: '/agendamento', label: 'Agendamento', icon: <CalendarDays size={16} /> },
      ],
    },
    {
      label: 'CADASTROS',
      items: [
        { to: '/empresas', label: 'Empresas', icon: <Building2 size={16} /> },
        { to: '/categorias', label: 'Categorias', icon: <Tag size={16} /> },
        { to: '/relatorios', label: 'Relatórios', icon: <BarChart3 size={16} /> },
      ],
    },
  ];

  return (
    <aside className="w-60 shrink-0 h-screen bg-white border-r border-slate-200 flex flex-col">
      {/* Logo */}
      <div className="flex items-center gap-2.5 px-5 py-5 border-b border-slate-100">
        <div className="w-7 h-7 rounded-lg bg-brand-400 flex items-center justify-center">
          <TrendingDown size={14} className="text-white" />
        </div>
        <span className="font-bold text-slate-900 text-sm">FinanceControl</span>
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-5">
        {groups.map((group) => (
          <div key={group.label}>
            <p className="text-[10px] font-semibold text-slate-400 tracking-widest px-2 mb-1.5">{group.label}</p>
            <ul className="space-y-0.5">
              {group.items.map((item) => (
                <li key={item.to}>
                  <NavLink
                    to={item.to}
                    className={({ isActive }) =>
                      clsx(
                        'flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm transition-colors',
                        isActive
                          ? 'bg-brand-50 text-brand-600 font-medium'
                          : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                      )
                    }
                  >
                    {item.icon}
                    <span className="flex-1">{item.label}</span>
                    {item.badgeCount !== undefined && item.badgeCount > 0 && (
                      <span className="text-xs bg-red-500 text-white rounded-full w-4 h-4 flex items-center justify-center leading-none">
                        {item.badgeCount > 9 ? '9+' : item.badgeCount}
                      </span>
                    )}
                  </NavLink>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </nav>

      {/* Empresa selector */}
      <div className="border-t border-slate-100 p-4">
        <p className="text-xs text-slate-400 mb-2">Empresas ativas</p>
        <div className="space-y-1">
          {empresas.filter((e) => e.ativo).slice(0, 3).map((e) => (
            <div key={e.id} className="flex items-center gap-2 text-xs text-slate-600">
              <span className="w-2 h-2 rounded-full" style={{ backgroundColor: e.cor }} />
              {e.nomeFantasia}
            </div>
          ))}
        </div>
      </div>
    </aside>
  );
}
