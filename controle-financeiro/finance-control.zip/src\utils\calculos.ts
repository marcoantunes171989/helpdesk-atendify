import { parseISO, isBefore, differenceInCalendarDays } from 'date-fns';

export const calcularParcelasValor = (valorTotal: number, nParcelas: number): number =>
  nParcelas > 0 ? valorTotal / nParcelas : 0;

export const calcularTotalParcelado = (valorParcela: number, nParcelas: number): number =>
  valorParcela * nParcelas;

export const calcularSaldo = (receitas: number, despesas: number): number =>
  receitas - despesas;

export const calcularPercentual = (valor: number, total: number): number =>
  total > 0 ? (valor / total) * 100 : 0;

export const isVencido = (dataVencimento: string): boolean => {
  const hoje = new Date();
  hoje.setHours(0, 0, 0, 0);
  return isBefore(parseISO(dataVencimento), hoje);
};

export const diasParaVencer = (dataVencimento: string): number =>
  differenceInCalendarDays(parseISO(dataVencimento), new Date());
