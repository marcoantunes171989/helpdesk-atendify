import { useState } from 'react';
import { format } from 'date-fns';
import { useFinanceStore } from '../store/useFinanceStore';
import { useEmpresaStore } from '../store/useEmpresaStore';
import { useCategoriaStore } from '../store/useCategoriaStore';
import { useToast } from '../components/ui/Toast';
import { Lancamento } from '../types';
import { fmtMoeda, fmtData } from '../utils/format';
import Table from '../components/ui/Table';
import Modal from '../components/ui/Modal';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import StatusBadge from '../components/shared/StatusBadge';
import KpiCard from '../components/shared/KpiCard';
import { ArrowDownCircle, TrendingDown, Clock, AlertCircle } from 'lucide-react';

export default function ContasPagar() {
  const { lancamentos, deleteLancamento, baixarLancamento } = useFinanceStore();
  const empresas = useEmpresaStore((s) => s.empresas);
  const categorias = useCategoriaStore((s) => s.categorias);
  const { toast } = useToast();

  const [busca, setBusca] = useState('');
  const [statusFiltro, setStatusFiltro] = useState('');
  const [catFiltro, setCatFiltro] = useState('');

  const [modalBaixa, setModalBaixa] = useState<Lancamento | null>(null);
  const [dataPagamento, setDataPagamento] = useState(format(new Date(), 'yyyy-MM-dd'));

  const debitos = lancamentos
    .filter((l) => l.tipo === 'debito')
    .filter((l) => !statusFiltro || l.status === statusFiltro)
    .filter((l) => !catFiltro || l.categoriaId === catFiltro)
    .filter((l) => !busca || l.descricao.toLowerCase().includes(busca.toLowerCase()))
    .map((l) => ({
      ...l,
      empresa: empresas.find((e) => e.id === l.empresaId),
      categoria: categorias.find((c) => c.id === l.categoriaId),
    }));

  const total = debitos.reduce((a, l) => a + l.valor, 0);
  const pago = debitos.filter((l) => l.status === 'pago').reduce((a, l) => a + l.valor, 0);
  const pendente = debitos.filter((l) => l.status === 'pendente').reduce((a, l) => a + l.valor, 0);
  const vencido = debitos.filter((l) => l.status === 'vencido').reduce((a, l) => a + l.valor, 0);

  const handleBaixa = () => {
    if (!modalBaixa) return;
    baixarLancamento(modalBaixa.id, dataPagamento);
    toast({ title: 'Baixa realizada!', description: `${modalBaixa.descricao} marcado como pago.`, variant: 'success' });
    setModalBaixa(null);
  };

  const columns = [
    { key: 'descricao', header: 'Descrição', render: (l: typeof debitos[0]) => (
      <div>
        <p className="text-sm font-medium text-slate-800 truncate max-w-[200px]">{l.descricao}</p>
        {l.parcelaAtual && l.numeroParcelas && (
          <p className="text-xs text-slate-400">{l.parcelaAtual}/{l.numeroParcelas}</p>
        )}
      </div>
    )},
    { key: 'empresa', header: 'Empresa', render: (l: typeof debitos[0]) => (
      <span className="text-xs text-slate-600">{l.empresa?.nomeFantasia ?? '-'}</span>
    )},
    { key: 'categoria', header: 'Categoria', render: (l: typeof debitos[0]) => (
      l.categoria ? (
        <span className="text-xs px-2 py-0.5 rounded-full" style={{ backgroundColor: l.categoria.cor + '20', color: l.categoria.cor }}>
          {l.categoria.nome}
        </span>
      ) : null
    )},
    { key: 'dataEmissao', header: 'Emissão', render: (l: typeof debitos[0]) => <span className="text-xs text-slate-500">{fmtData(l.dataEmissao)}</span> },
    { key: 'dataVencimento', header: 'Vencimento', render: (l: typeof debitos[0]) => <span className="text-xs text-slate-500">{fmtData(l.dataVencimento)}</span> },
    { key: 'valor', header: 'Valor', align: 'right' as const, render: (l: typeof debitos[0]) => (
      <span className="text-sm font-semibold text-red-600">{fmtMoeda(l.valor)}</span>
    )},
    { key: 'status', header: 'Situação', render: (l: typeof debitos[0]) => <StatusBadge status={l.status} /> },
    { key: 'acoes', header: 'Ações', render: (l: typeof debitos[0]) => (
      <div className="flex items-center gap-1">
        {(l.status === 'pendente' || l.status === 'vencido') && (
          <Button size="sm" variant="secondary" onClick={() => { setModalBaixa(l); setDataPagamento(format(new Date(), 'yyyy-MM-dd')); }}>
            Baixar
          </Button>
        )}
        <Button size="sm" variant="danger" onClick={() => { deleteLancamento(l.id); toast({ title: 'Excluído', variant: 'info' }); }}>
          Excluir
        </Button>
      </div>
    )},
  ];

  return (
    <div className="space-y-5">
      {/* KPIs */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
        <KpiCard title="Total" value={total} icon={<ArrowDownCircle size={18} />} colorVariant="blue" />
        <KpiCard title="Pago" value={pago} icon={<TrendingDown size={18} />} colorVariant="green" />
        <KpiCard title="Pendente" value={pendente} icon={<Clock size={18} />} colorVariant="amber" />
        <KpiCard title="Vencido" value={vencido} icon={<AlertCircle size={18} />} colorVariant="red" />
      </div>

      {/* Filtros */}
      <div className="flex flex-wrap gap-3">
        <input
          className="input w-48 flex-1"
          placeholder="Buscar..."
          value={busca}
          onChange={(e) => setBusca(e.target.value)}
        />
        <select className="input w-40" value={statusFiltro} onChange={(e) => setStatusFiltro(e.target.value)}>
          <option value="">Todos os status</option>
          <option value="pendente">Pendente</option>
          <option value="pago">Pago</option>
          <option value="vencido">Vencido</option>
          <option value="cancelado">Cancelado</option>
        </select>
        <select className="input w-48" value={catFiltro} onChange={(e) => setCatFiltro(e.target.value)}>
          <option value="">Todas categorias</option>
          {categorias.filter((c) => c.tipo === 'debito').map((c) => (
            <option key={c.id} value={c.id}>{c.nome}</option>
          ))}
        </select>
      </div>

      {/* Tabela */}
      <Table columns={columns} data={debitos} emptyMessage="Nenhuma conta a pagar encontrada" />

      {/* Totais */}
      <div className="flex justify-end gap-4 text-sm text-slate-600 px-4">
        <span>Total filtrado: <strong className="text-slate-900">{fmtMoeda(total)}</strong></span>
      </div>

      {/* Modal de baixa */}
      <Modal
        open={!!modalBaixa}
        onClose={() => setModalBaixa(null)}
        title="Dar baixa no pagamento"
        footer={
          <>
            <Button variant="secondary" onClick={() => setModalBaixa(null)}>Cancelar</Button>
            <Button variant="primary" onClick={handleBaixa}>Confirmar</Button>
          </>
        }
      >
        {modalBaixa && (
          <div className="space-y-4">
            <p className="text-sm text-slate-600">
              Confirmar pagamento de <strong>{modalBaixa.descricao}</strong> no valor de{' '}
              <strong>{fmtMoeda(modalBaixa.valor)}</strong>?
            </p>
            <Input
              type="date"
              label="Data do pagamento"
              value={dataPagamento}
              onChange={(e) => setDataPagamento(e.target.value)}
            />
          </div>
        )}
      </Modal>
    </div>
  );
}
