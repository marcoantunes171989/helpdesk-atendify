import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useState, useCallback } from 'react';
import { format } from 'date-fns';
import { clsx } from 'clsx';
import { useFinanceStore } from '../store/useFinanceStore';
import { useEmpresaStore } from '../store/useEmpresaStore';
import { useCategoriaStore } from '../store/useCategoriaStore';
import { lancamentoSchema, LancamentoFormData } from '../utils/validators';
import { calcularParcelasValor, calcularTotalParcelado } from '../utils/calculos';
import { fmtMoeda } from '../utils/format';
import Input from '../components/ui/Input';
import Select from '../components/ui/Select';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';
import DropZone from '../components/ui/DropZone';
import LancamentoRow from '../components/shared/LancamentoRow';
import { useToast } from '../components/ui/Toast';
import { Lancamento } from '../types';

function useMaskMoeda() {
  const format = useCallback((raw: string) => {
    const digits = raw.replace(/\D/g, '');
    if (!digits) return '';
    const num = parseInt(digits, 10) / 100;
    return num.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }, []);

  const parse = useCallback((formatted: string): number => {
    return parseFloat(formatted.replace(/\./g, '').replace(',', '.')) || 0;
  }, []);

  return { format, parse };
}

export default function Lancamentos() {
  const { lancamentos, addLancamento, deleteLancamento } = useFinanceStore();
  const empresas = useEmpresaStore((s) => s.empresas);
  const categorias = useCategoriaStore((s) => s.categorias);
  const { toast } = useToast();
  const { format: maskFmt, parse: maskParse } = useMaskMoeda();
  const [valorDisplay, setValorDisplay] = useState('');
  const [tipo, setTipo] = useState<'credito' | 'debito'>('debito');

  const { register, handleSubmit, watch, reset, setValue, formState: { errors, isSubmitting } } = useForm<LancamentoFormData>({
    resolver: zodResolver(lancamentoSchema),
    defaultValues: {
      tipo: 'debito',
      tipoRecorrencia: 'avista',
      dataEmissao: format(new Date(), 'yyyy-MM-dd'),
    },
  });

  const tipoRecorrencia = watch('tipoRecorrencia');
  const numeroParcelas = watch('numeroParcelas') ?? 1;
  const valorNum = maskParse(valorDisplay);

  const onSubmit = (data: LancamentoFormData) => {
    const valorFinal = valorNum;
    const valorTotalFinal = data.tipoRecorrencia === 'parcelas'
      ? calcularTotalParcelado(valorFinal, data.numeroParcelas ?? 1)
      : valorFinal;

    addLancamento({
      tipo: data.tipo,
      descricao: data.descricao,
      empresaId: data.empresaId,
      categoriaId: data.categoriaId,
      valor: valorFinal,
      valorTotal: valorTotalFinal,
      dataEmissao: data.dataEmissao,
      dataVencimento: data.dataVencimento,
      status: 'pendente',
      tipoRecorrencia: data.tipoRecorrencia,
      recorrencia: data.recorrencia,
      numeroParcelas: data.numeroParcelas,
      diaVencimento: data.diaVencimento,
      observacoes: data.observacoes,
      anexos: [],
      competencia: data.dataVencimento.substring(0, 7),
    });

    toast({ title: 'Lançamento salvo!', variant: 'success' });
    reset({ tipo, tipoRecorrencia: 'avista', dataEmissao: format(new Date(), 'yyyy-MM-dd') });
    setValorDisplay('');
  };

  const recentes = [...lancamentos]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 8)
    .map((l) => ({
      ...l,
      empresa: empresas.find((e) => e.id === l.empresaId),
      categoria: categorias.find((c) => c.id === l.categoriaId),
    }));

  const categoriasFiltradas = categorias.filter((c) => c.tipo === tipo && c.ativo);

  const handleTipoChange = (t: 'credito' | 'debito') => {
    setTipo(t);
    setValue('tipo', t);
    setValue('categoriaId', '');
  };

  return (
    <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
      {/* Formulário */}
      <Card title="Novo Lançamento" padding="none">
        <form onSubmit={handleSubmit(onSubmit)} className="p-5 space-y-4">
          {/* Tipo toggle */}
          <div>
            <span className="label">Tipo</span>
            <div className="grid grid-cols-2 gap-2">
              {(['credito', 'debito'] as const).map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => handleTipoChange(t)}
                  className={clsx(
                    'py-2.5 rounded-lg text-sm font-medium border transition-all',
                    tipo === t
                      ? t === 'credito'
                        ? 'bg-emerald-500 text-white border-emerald-500'
                        : 'bg-red-500 text-white border-red-500'
                      : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                  )}
                >
                  {t === 'credito' ? '↑ Crédito / Receita' : '↓ Débito / Despesa'}
                </button>
              ))}
            </div>
            <input type="hidden" {...register('tipo')} />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <Select
              label="Empresa"
              options={empresas.filter((e) => e.ativo).map((e) => ({ value: e.id, label: e.nomeFantasia }))}
              placeholder="Selecione..."
              error={errors.empresaId?.message}
              {...register('empresaId')}
            />
            <Select
              label="Categoria"
              options={categoriasFiltradas.map((c) => ({ value: c.id, label: c.nome }))}
              placeholder="Selecione..."
              error={errors.categoriaId?.message}
              {...register('categoriaId')}
            />
          </div>

          <Input
            label="Descrição"
            placeholder="Descreva o lançamento..."
            error={errors.descricao?.message}
            {...register('descricao')}
          />

          <div>
            <label className="label">Valor</label>
            <input
              type="text"
              inputMode="numeric"
              className={clsx('input', errors.valor && 'border-red-400')}
              placeholder="0,00"
              value={valorDisplay}
              onChange={(e) => {
                const masked = maskFmt(e.target.value);
                setValorDisplay(masked);
                setValue('valor', maskParse(masked));
              }}
            />
            {errors.valor && <p className="mt-1 text-xs text-red-600">{errors.valor.message}</p>}
          </div>

          <div className="grid grid-cols-2 gap-3">
            <Input
              type="date"
              label="Data de Emissão"
              error={errors.dataEmissao?.message}
              {...register('dataEmissao')}
            />
            <Input
              type="date"
              label="Data de Vencimento"
              error={errors.dataVencimento?.message}
              {...register('dataVencimento')}
            />
          </div>

          {/* Tipo recorrência */}
          <div>
            <span className="label">Tipo de pagamento</span>
            <div className="grid grid-cols-3 gap-2">
              {(['avista', 'fixo', 'parcelas'] as const).map((tr) => (
                <button
                  key={tr}
                  type="button"
                  onClick={() => setValue('tipoRecorrencia', tr)}
                  className={clsx(
                    'py-2 rounded-lg text-xs font-medium border transition-all',
                    tipoRecorrencia === tr
                      ? 'bg-brand-400 text-white border-brand-400'
                      : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                  )}
                >
                  {tr === 'avista' ? 'À Vista' : tr === 'fixo' ? 'Conta Fixa' : 'Parcelado'}
                </button>
              ))}
            </div>
            <input type="hidden" {...register('tipoRecorrencia')} />
          </div>

          {tipoRecorrencia === 'parcelas' && (
            <div className="p-3 bg-slate-50 rounded-lg space-y-3">
              <Input
                type="number"
                label="Número de parcelas"
                min={2}
                max={120}
                error={errors.numeroParcelas?.message}
                {...register('numeroParcelas', { valueAsNumber: true })}
              />
              {valorNum > 0 && numeroParcelas >= 2 && (
                <div className="text-xs text-slate-600 bg-white border border-slate-200 rounded-lg p-2.5">
                  <p>Valor por parcela: <strong>{fmtMoeda(calcularParcelasValor(valorNum, numeroParcelas))}</strong></p>
                  <p>Total: <strong>{fmtMoeda(calcularTotalParcelado(valorNum, numeroParcelas))}</strong></p>
                </div>
              )}
            </div>
          )}

          {tipoRecorrencia === 'fixo' && (
            <div className="p-3 bg-slate-50 rounded-lg grid grid-cols-2 gap-3">
              <Select
                label="Recorrência"
                options={[
                  { value: 'mensal', label: 'Mensal' },
                  { value: 'bimestral', label: 'Bimestral' },
                  { value: 'trimestral', label: 'Trimestral' },
                  { value: 'semestral', label: 'Semestral' },
                  { value: 'anual', label: 'Anual' },
                ]}
                placeholder="Selecione..."
                {...register('recorrencia')}
              />
              <Input
                type="number"
                label="Dia de vencimento"
                min={1}
                max={31}
                placeholder="Ex: 10"
                {...register('diaVencimento', { valueAsNumber: true })}
              />
            </div>
          )}

          {/* Anexos */}
          <div className="grid grid-cols-2 gap-3">
            <DropZone
              label="Boleto / NF"
              onFilesAccepted={() => {}}
              hint="PDF, PNG, JPG"
            />
            <DropZone
              label="Comprovante"
              onFilesAccepted={() => {}}
              hint="PDF, PNG, JPG"
            />
          </div>

          <div>
            <label className="label">Observações</label>
            <textarea
              className="input min-h-[60px] resize-none"
              placeholder="Observações adicionais..."
              {...register('observacoes')}
            />
          </div>

          <div className="flex gap-2 pt-1">
            <Button
              type="button"
              variant="secondary"
              className="flex-1"
              onClick={() => { reset(); setValorDisplay(''); }}
            >
              Limpar
            </Button>
            <Button type="submit" variant="primary" className="flex-1" loading={isSubmitting}>
              Salvar lançamento
            </Button>
          </div>
        </form>
      </Card>

      {/* Lista recente */}
      <div className="space-y-4">
        <Card title="Lançamentos Recentes" padding="sm">
          <div className="divide-y divide-slate-50">
            {recentes.map((l) => (
              <LancamentoRow
                key={l.id}
                lancamento={l as Lancamento}
                onDelete={(id) => {
                  deleteLancamento(id);
                  toast({ title: 'Lançamento excluído', variant: 'info' });
                }}
              />
            ))}
          </div>
        </Card>

        {/* Resumo do mês */}
        <Card title="Resumo do Mês" padding="sm">
          {(() => {
            const comp = format(new Date(), 'yyyy-MM');
            const doMes = lancamentos.filter((l) => l.competencia === comp);
            const receitas = doMes.filter((l) => l.tipo === 'credito').reduce((a, l) => a + l.valor, 0);
            const despesas = doMes.filter((l) => l.tipo === 'debito').reduce((a, l) => a + l.valor, 0);
            const saldo = receitas - despesas;
            const max = Math.max(receitas, despesas, 1);
            return (
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-xs text-slate-600 mb-1">
                    <span>Receitas</span><span className="font-medium text-emerald-600">{fmtMoeda(receitas)}</span>
                  </div>
                  <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                    <div className="h-full bg-emerald-400 rounded-full" style={{ width: `${(receitas / max) * 100}%` }} />
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-xs text-slate-600 mb-1">
                    <span>Despesas</span><span className="font-medium text-red-600">{fmtMoeda(despesas)}</span>
                  </div>
                  <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                    <div className="h-full bg-red-400 rounded-full" style={{ width: `${(despesas / max) * 100}%` }} />
                  </div>
                </div>
                <div className="pt-2 border-t border-slate-100 flex justify-between text-sm">
                  <span className="text-slate-600">Saldo</span>
                  <span className={`font-semibold ${saldo >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>{fmtMoeda(saldo)}</span>
                </div>
              </div>
            );
          })()}
        </Card>
      </div>
    </div>
  );
}
