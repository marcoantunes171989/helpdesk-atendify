import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Plus, Pencil, Power, Building2 } from 'lucide-react';
import { useEmpresaStore } from '../store/useEmpresaStore';
import { useFinanceStore } from '../store/useFinanceStore';
import { empresaSchema, EmpresaFormData } from '../utils/validators';
import { fmtMoeda } from '../utils/format';
import { Empresa } from '../types';
import Modal from '../components/ui/Modal';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import { useToast } from '../components/ui/Toast';

function getInitials(nome: string) {
  return nome.split(' ').slice(0, 2).map((n) => n[0]).join('').toUpperCase();
}

export default function Empresas() {
  const { empresas, addEmpresa, updateEmpresa } = useEmpresaStore();
  const { lancamentos } = useFinanceStore();
  const { toast } = useToast();

  const [modalOpen, setModalOpen] = useState(false);
  const [editando, setEditando] = useState<Empresa | null>(null);
  const [selecionada, setSelecionada] = useState<Empresa | null>(null);

  const { register, handleSubmit, reset, formState: { errors } } = useForm<EmpresaFormData>({
    resolver: zodResolver(empresaSchema),
    defaultValues: { cor: '#1D9E75' },
  });

  const abrirNova = () => {
    setEditando(null);
    reset({ cor: '#1D9E75' });
    setModalOpen(true);
  };

  const abrirEditar = (e: Empresa) => {
    setEditando(e);
    reset(e);
    setModalOpen(true);
  };

  const onSubmit = (data: EmpresaFormData) => {
    if (editando) {
      updateEmpresa(editando.id, data);
      toast({ title: 'Empresa atualizada!', variant: 'success' });
    } else {
      addEmpresa({ ...data, ativo: true });
      toast({ title: 'Empresa cadastrada!', variant: 'success' });
    }
    setModalOpen(false);
  };

  const getLancamentosEmpresa = (id: string) =>
    lancamentos.filter((l) => l.empresaId === id);

  const getEmAberto = (id: string) =>
    lancamentos
      .filter((l) => l.empresaId === id && (l.status === 'pendente' || l.status === 'vencido'))
      .reduce((a, l) => a + l.valor, 0);

  return (
    <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
      {/* Grid de empresas */}
      <div className="xl:col-span-2">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-sm font-semibold text-slate-900">Empresas cadastradas</h2>
          <Button icon={<Plus size={14} />} onClick={abrirNova}>Nova empresa</Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {empresas.map((empresa) => {
            const lancEmpresa = getLancamentosEmpresa(empresa.id);
            const emAberto = getEmAberto(empresa.id);

            return (
              <div
                key={empresa.id}
                onClick={() => setSelecionada(empresa)}
                className={`card p-4 cursor-pointer transition-all hover:shadow-md ${selecionada?.id === empresa.id ? 'ring-2 ring-brand-400' : ''} ${!empresa.ativo ? 'opacity-60' : ''}`}
              >
                <div className="flex items-start gap-3">
                  <div
                    className="w-10 h-10 rounded-lg flex items-center justify-center text-white text-sm font-bold shrink-0"
                    style={{ backgroundColor: empresa.cor }}
                  >
                    {getInitials(empresa.nomeFantasia)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-slate-900 truncate">{empresa.nomeFantasia}</p>
                    <p className="text-xs text-slate-500">{empresa.cnpj}</p>
                    <p className="text-xs text-slate-400">{empresa.cidade}/{empresa.estado}</p>
                  </div>
                </div>
                <div className="flex justify-between items-center mt-3 pt-3 border-t border-slate-100">
                  <div className="text-xs text-slate-500">
                    <span>{lancEmpresa.length} lançamentos</span>
                  </div>
                  <div className="text-xs">
                    {emAberto > 0 && (
                      <span className="text-amber-600 font-medium">{fmtMoeda(emAberto)} em aberto</span>
                    )}
                  </div>
                  <div className="flex gap-1">
                    <button
                      onClick={(e) => { e.stopPropagation(); abrirEditar(empresa); }}
                      className="p-1 rounded text-slate-400 hover:bg-slate-100"
                    >
                      <Pencil size={12} />
                    </button>
                    <button
                      onClick={(e) => { e.stopPropagation(); updateEmpresa(empresa.id, { ativo: !empresa.ativo }); }}
                      className={`p-1 rounded ${empresa.ativo ? 'text-slate-400 hover:bg-slate-100' : 'text-emerald-500 hover:bg-emerald-50'}`}
                    >
                      <Power size={12} />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Painel lateral */}
      <div>
        {selecionada ? (
          <div className="card p-5 space-y-4">
            <div className="flex items-center gap-3">
              <div
                className="w-12 h-12 rounded-xl flex items-center justify-center text-white font-bold"
                style={{ backgroundColor: selecionada.cor }}
              >
                {getInitials(selecionada.nomeFantasia)}
              </div>
              <div>
                <h3 className="font-semibold text-slate-900">{selecionada.nomeFantasia}</h3>
                <p className="text-xs text-slate-500">{selecionada.razaoSocial}</p>
              </div>
            </div>

            <div className="space-y-2 text-xs text-slate-600">
              <p><span className="text-slate-400">CNPJ:</span> {selecionada.cnpj}</p>
              <p><span className="text-slate-400">Email:</span> {selecionada.email}</p>
              <p><span className="text-slate-400">Tel:</span> {selecionada.telefone}</p>
              <p><span className="text-slate-400">Cidade:</span> {selecionada.cidade}/{selecionada.estado}</p>
            </div>

            {/* KPIs */}
            {(() => {
              const lancs = getLancamentosEmpresa(selecionada.id);
              const receitas = lancs.filter((l) => l.tipo === 'credito').reduce((a, l) => a + l.valor, 0);
              const despesas = lancs.filter((l) => l.tipo === 'debito').reduce((a, l) => a + l.valor, 0);
              return (
                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100">
                  <div className="bg-emerald-50 rounded-lg p-2.5">
                    <p className="text-xs text-slate-500">Receitas</p>
                    <p className="text-sm font-semibold text-emerald-600">{fmtMoeda(receitas)}</p>
                  </div>
                  <div className="bg-red-50 rounded-lg p-2.5">
                    <p className="text-xs text-slate-500">Despesas</p>
                    <p className="text-sm font-semibold text-red-600">{fmtMoeda(despesas)}</p>
                  </div>
                </div>
              );
            })()}
          </div>
        ) : (
          <div className="card p-8 flex flex-col items-center gap-3 text-slate-400">
            <Building2 size={32} />
            <p className="text-sm">Selecione uma empresa</p>
          </div>
        )}
      </div>

      {/* Modal */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editando ? 'Editar empresa' : 'Nova empresa'}
        size="md"
        footer={
          <>
            <Button variant="secondary" onClick={() => setModalOpen(false)}>Cancelar</Button>
            <Button variant="primary" onClick={handleSubmit(onSubmit)}>
              {editando ? 'Salvar' : 'Cadastrar'}
            </Button>
          </>
        }
      >
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <Input label="Razão Social" error={errors.razaoSocial?.message} {...register('razaoSocial')} />
            <Input label="Nome Fantasia" error={errors.nomeFantasia?.message} {...register('nomeFantasia')} />
          </div>
          <Input label="CNPJ" placeholder="00.000.000/0000-00" error={errors.cnpj?.message} {...register('cnpj')} />
          <div className="grid grid-cols-2 gap-3">
            <Input label="Telefone" error={errors.telefone?.message} {...register('telefone')} />
            <Input label="E-mail" type="email" error={errors.email?.message} {...register('email')} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Input label="Cidade" error={errors.cidade?.message} {...register('cidade')} />
            <Input label="Estado (UF)" maxLength={2} error={errors.estado?.message} {...register('estado')} />
          </div>
          <div>
            <label className="label">Cor</label>
            <input type="color" className="w-10 h-8 rounded border border-slate-200 cursor-pointer" {...register('cor')} />
          </div>
        </div>
      </Modal>
    </div>
  );
}
