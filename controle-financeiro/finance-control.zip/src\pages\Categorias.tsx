import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { Plus, Pencil, Trash2 } from 'lucide-react';
import { useCategoriaStore } from '../store/useCategoriaStore';
import { useFinanceStore } from '../store/useFinanceStore';
import { fmtMoeda } from '../utils/format';
import { Categoria, TipoLancamento } from '../types';
import Modal from '../components/ui/Modal';
import Button from '../components/ui/Button';
import Input from '../components/ui/Input';
import Select from '../components/ui/Select';
import { useToast } from '../components/ui/Toast';
import { format } from 'date-fns';

const categoriaFormSchema = z.object({
  nome: z.string().min(2, 'Mínimo 2 caracteres'),
  tipo: z.enum(['debito', 'credito']),
  cor: z.string(),
  icone: z.string(),
  ativo: z.boolean().default(true),
});
type CategoriaFormData = z.infer<typeof categoriaFormSchema>;

const iconeOpcoes = [
  { value: 'briefcase', label: 'Pasta' },
  { value: 'shopping-cart', label: 'Carrinho' },
  { value: 'building-2', label: 'Prédio' },
  { value: 'zap', label: 'Energia' },
  { value: 'wifi', label: 'Internet' },
  { value: 'users', label: 'Pessoas' },
  { value: 'truck', label: 'Caminhão' },
  { value: 'file-text', label: 'Documento' },
  { value: 'tool', label: 'Ferramenta' },
  { value: 'megaphone', label: 'Megafone' },
  { value: 'coins', label: 'Moedas' },
  { value: 'more-horizontal', label: 'Outros' },
];

function CategoriaCard({ cat, lancamentos, onEdit, onDelete }: {
  cat: Categoria;
  lancamentos: import('../types').Lancamento[];
  onEdit: () => void;
  onDelete: () => void;
}) {
  const comp = format(new Date(), 'yyyy-MM');
  const total = lancamentos
    .filter((l) => l.categoriaId === cat.id && l.competencia === comp)
    .reduce((a, l) => a + l.valor, 0);
  const count = lancamentos.filter((l) => l.categoriaId === cat.id).length;

  return (
    <div className="card p-4 flex items-center gap-3">
      <div className="w-10 h-10 rounded-full flex items-center justify-center shrink-0" style={{ backgroundColor: cat.cor + '20' }}>
        <span className="text-lg" style={{ color: cat.cor }}>●</span>
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-semibold text-slate-800">{cat.nome}</p>
        <p className="text-xs text-slate-400">{count} lançamentos · {fmtMoeda(total)} este mês</p>
      </div>
      <div className="flex gap-1">
        <button onClick={onEdit} className="p-1.5 rounded text-slate-400 hover:bg-slate-100">
          <Pencil size={13} />
        </button>
        <button onClick={onDelete} className="p-1.5 rounded text-red-400 hover:bg-red-50">
          <Trash2 size={13} />
        </button>
      </div>
    </div>
  );
}

export default function Categorias() {
  const { categorias, addCategoria, updateCategoria, deleteCategoria } = useCategoriaStore();
  const { lancamentos } = useFinanceStore();
  const { toast } = useToast();

  const [modalOpen, setModalOpen] = useState(false);
  const [editando, setEditando] = useState<Categoria | null>(null);
  const [tipoModal, setTipoModal] = useState<TipoLancamento>('debito');

  const { register, handleSubmit, reset, formState: { errors } } = useForm<CategoriaFormData>({
    resolver: zodResolver(categoriaFormSchema),
    defaultValues: { cor: '#1D9E75', icone: 'briefcase', ativo: true },
  });

  const abrirNova = (tipo: TipoLancamento) => {
    setTipoModal(tipo);
    setEditando(null);
    reset({ tipo, cor: '#1D9E75', icone: 'briefcase', ativo: true });
    setModalOpen(true);
  };

  const abrirEditar = (cat: Categoria) => {
    setEditando(cat);
    setTipoModal(cat.tipo);
    reset(cat);
    setModalOpen(true);
  };

  const onSubmit = (data: CategoriaFormData) => {
    if (editando) {
      updateCategoria(editando.id, data);
      toast({ title: 'Categoria atualizada!', variant: 'success' });
    } else {
      addCategoria(data);
      toast({ title: 'Categoria criada!', variant: 'success' });
    }
    setModalOpen(false);
  };

  const despesas = categorias.filter((c) => c.tipo === 'debito');
  const receitas = categorias.filter((c) => c.tipo === 'credito');

  return (
    <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
      {/* Despesas */}
      <div>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-sm font-semibold text-red-600">Despesas</h2>
          <Button size="sm" variant="secondary" icon={<Plus size={12} />} onClick={() => abrirNova('debito')}>
            Nova categoria
          </Button>
        </div>
        <div className="space-y-2">
          {despesas.map((cat) => (
            <CategoriaCard
              key={cat.id}
              cat={cat}
              lancamentos={lancamentos}
              onEdit={() => abrirEditar(cat)}
              onDelete={() => { deleteCategoria(cat.id); toast({ title: 'Categoria excluída', variant: 'info' }); }}
            />
          ))}
        </div>
      </div>

      {/* Receitas */}
      <div>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-sm font-semibold text-emerald-600">Receitas</h2>
          <Button size="sm" variant="secondary" icon={<Plus size={12} />} onClick={() => abrirNova('credito')}>
            Nova categoria
          </Button>
        </div>
        <div className="space-y-2">
          {receitas.map((cat) => (
            <CategoriaCard
              key={cat.id}
              cat={cat}
              lancamentos={lancamentos}
              onEdit={() => abrirEditar(cat)}
              onDelete={() => { deleteCategoria(cat.id); toast({ title: 'Categoria excluída', variant: 'info' }); }}
            />
          ))}
        </div>
      </div>

      {/* Modal */}
      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editando ? 'Editar categoria' : `Nova categoria de ${tipoModal === 'debito' ? 'despesa' : 'receita'}`}
        footer={
          <>
            <Button variant="secondary" onClick={() => setModalOpen(false)}>Cancelar</Button>
            <Button variant="primary" onClick={handleSubmit(onSubmit)}>Salvar</Button>
          </>
        }
      >
        <div className="space-y-3">
          <input type="hidden" {...register('tipo')} />
          <input type="hidden" {...register('ativo')} />
          <Input label="Nome" error={errors.nome?.message} {...register('nome')} />
          <Select
            label="Ícone"
            options={iconeOpcoes}
            error={errors.icone?.message}
            {...register('icone')}
          />
          <div>
            <label className="label">Cor</label>
            <input type="color" className="w-10 h-8 rounded border border-slate-200 cursor-pointer" {...register('cor')} />
          </div>
        </div>
      </Modal>
    </div>
  );
}
